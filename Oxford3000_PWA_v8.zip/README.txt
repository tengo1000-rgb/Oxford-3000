Oxford 3000 Trainer v8 — PWA

Файлы:
- index.html — приложение
- manifest.webmanifest — установка на главный экран
- sw.js — офлайн-режим
- icon-192.png / icon-512.png — иконки

Важно: Android/Chrome не устанавливает PWA из content:// или file://.
Для кнопки «Установить» приложение нужно открыть по HTTPS (или localhost).
После установки оно может работать офлайн благодаря service worker.
